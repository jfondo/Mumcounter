package com.example.mumcounter

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

// ================= Data (Room, on-device only) =================

@Entity(tableName = "mum_events")
data class MumEvent(@PrimaryKey(autoGenerate = true) val id: Long = 0, val timestamp: Long)

@Dao
interface MumDao {
    @Insert suspend fun insert(event: MumEvent)

    @Query("SELECT * FROM mum_events WHERE timestamp >= :from ORDER BY timestamp ASC")
    fun eventsSince(from: Long): Flow<List<MumEvent>>

    @Query("DELETE FROM mum_events WHERE id = (SELECT id FROM mum_events ORDER BY timestamp DESC LIMIT 1)")
    suspend fun deleteLast()
}

@Database(entities = [MumEvent::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() { abstract fun dao(): MumDao }

data class UiState(val today: Int = 0, val week: Int = 0, val hourly: List<Int> = List(24) { 0 })

class MumViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = Room.databaseBuilder(app, AppDb::class.java, "mum.db").build().dao()
    private val zone = ZoneId.systemDefault()
    private val prefs = app.getSharedPreferences("mum", Context.MODE_PRIVATE)

    var onboarded by mutableStateOf(prefs.getBoolean("onboarded", false))
        private set

    fun finishOnboarding() {
        prefs.edit().putBoolean("onboarded", true).apply()
        onboarded = true
    }

    private fun startOfDay(daysAgo: Long = 0) =
        LocalDate.now(zone).minusDays(daysAgo).atStartOfDay(zone).toInstant().toEpochMilli()

    val state: StateFlow<UiState> = dao.eventsSince(startOfDay(6)).map { events ->
        val todays = events.filter { it.timestamp >= startOfDay() }
        val hourly = IntArray(24)
        todays.forEach { hourly[Instant.ofEpochMilli(it.timestamp).atZone(zone).hour]++ }
        UiState(todays.size, events.size, hourly.toList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    fun tap() = viewModelScope.launch { dao.insert(MumEvent(timestamp = System.currentTimeMillis())) }
    fun undo() = viewModelScope.launch { dao.deleteLast() }
}

// ================= Theme =================

private val Bg = Color(0xFFFBF5EE)
private val Surface = Color(0xFFFFFCF8)
private val SurfaceHi = Color(0xFFF3E7DB)
private val Coral = Color(0xFFE2603F)
private val CoralDim = Color(0xFFF0B8A5)
private val CoralFaint = Color(0xFFF5E2D8)
private val TextMain = Color(0xFF3B302A)
private val TextSoft = Color(0xFF8C7B6E)

// Add plus_jakarta_sans_regular.ttf and plus_jakarta_sans_medium.ttf to app/src/main/res/font/
// (free from fonts.google.com/specimen/Plus+Jakarta+Sans)
private val AppFont = FontFamily(
    Font(R.font.plus_jakarta_sans_regular, FontWeight.Normal),
    Font(R.font.plus_jakarta_sans_medium, FontWeight.Medium)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Coral, background = Bg, surface = Surface)) {
                val vm: MumViewModel = viewModel()
                CompositionLocalProvider(LocalTextStyle provides TextStyle(fontFamily = AppFont)) {
                    Box(Modifier.fillMaxSize().background(Bg)) {
                        if (vm.onboarded) AppRoot(vm) else Onboarding(onDone = vm::finishOnboarding)
                    }
                }
            }
        }
    }
}

// ================= Onboarding: explains the objective =================

private data class Slide(val title: String, val body: String)

private val slides = listOf(
    Slide("Every \"Mum\" is a moment of attention",
        "Mothers answer thousands of small calls every week: for help, comfort, a snack, an answer. It rarely gets counted."),
    Slide("Tap each time you're called",
        "One tap, one count. Your day builds into a picture of the attention motherhood asks for."),
    Slide("Together, it adds up",
        "Daily totals are shared anonymously and grouped by country. No names, no recordings, no exact location.")
)

@Composable
fun Onboarding(onDone: () -> Unit) {
    val pager = rememberPagerState(pageCount = { slides.size })
    val scope = rememberCoroutineScope()
    val last = pager.currentPage == slides.lastIndex

    Column(Modifier.fillMaxSize().padding(24.dp).systemBarsPadding()) {
        HorizontalPager(pager, Modifier.weight(1f)) { i ->
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                Box(
                    Modifier.size(64.dp).clip(CircleShape).background(SurfaceHi),
                    contentAlignment = Alignment.Center
                ) { Text("\u2665", color = Coral, fontSize = 28.sp) }
                Spacer(Modifier.height(28.dp))
                Text(slides[i].title, color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.Medium, lineHeight = 36.sp)
                Spacer(Modifier.height(14.dp))
                Text(slides[i].body, color = TextSoft, fontSize = 16.sp, lineHeight = 24.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 20.dp), horizontalArrangement = Arrangement.Center) {
            repeat(slides.size) { i ->
                val active = i == pager.currentPage
                Box(
                    Modifier.padding(3.dp)
                        .size(width = if (active) 18.dp else 6.dp, height = 6.dp)
                        .clip(CircleShape)
                        .background(if (active) Coral else CoralFaint)
                )
            }
        }
        Button(
            onClick = {
                if (last) onDone() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = Coral, contentColor = Bg)
        ) { Text(if (last) "Get started" else "Next", fontSize = 16.sp, fontWeight = FontWeight.Medium) }
    }
}

// ================= App shell with pill navigation =================

@Composable
fun AppRoot(vm: MumViewModel) {
    var tab by remember { mutableStateOf("Today") }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                "Today" -> TodayScreen(vm)
                else -> AboutScreen()
            }
        }
        Row(
            Modifier.padding(16.dp).fillMaxWidth().clip(CircleShape).background(Surface).padding(5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("Today", "About").forEach { name ->
                val sel = tab == name
                Box(
                    Modifier.weight(1f).clip(CircleShape)
                        .background(if (sel) SurfaceHi else Color.Transparent)
                        .clickable { tab = name }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text(name, color = if (sel) TextMain else TextSoft, fontSize = 14.sp) }
            }
        }
    }
}

// ================= Today =================

@Composable
fun TodayScreen(vm: MumViewModel) {
    val s by vm.state.collectAsState()
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current

    // Ring fills toward the next milestone of 50
    val progress by animateFloatAsState((s.today % 50) / 50f, label = "ring")

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Today", color = TextSoft, fontSize = 13.sp)
                Text("${s.today} so far", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            }
            TextButton(onClick = { shareCount(context, s.today) }) { Text("Share", color = Coral) }
        }

        Spacer(Modifier.weight(1f))

        Box(
            Modifier.size(240.dp).clip(CircleShape).clickable {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                vm.tap()
            },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 10.dp.toPx()
                val inset = stroke / 2
                val arcSize = Size(size.width - stroke, size.height - stroke)
                drawArc(CoralFaint, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
                drawArc(Coral, -90f, 360f * progress, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                drawCircle(Coral, radius = size.minDimension / 2 - stroke * 2)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Mum", color = Bg, fontSize = 48.sp, fontWeight = FontWeight.Medium)
                Text("tap", color = Color(0xFFFFE3D8), fontSize = 14.sp)
            }
        }

        Spacer(Modifier.height(12.dp))
        TextButton(onClick = { vm.undo() }) { Text("Undo last", color = TextSoft) }

        Spacer(Modifier.weight(1f))

        HourlyBars(s.hourly)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("12am", "6am", "12pm", "6pm").forEach { Text(it, color = TextSoft, fontSize = 11.sp) }
        }
        Spacer(Modifier.height(8.dp))
        Text("${s.week} in the last 7 days", color = TextSoft, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun HourlyBars(hourly: List<Int>) {
    val max = (hourly.maxOrNull() ?: 0).coerceAtLeast(1)
    val peak = hourly.indexOf(hourly.maxOrNull() ?: 0)
    Row(
        Modifier.fillMaxWidth().height(56.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        hourly.forEachIndexed { hour, count ->
            Box(
                Modifier.weight(1f)
                    .fillMaxHeight((count.toFloat() / max).coerceIn(0.05f, 1f))
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        when {
                            hour == peak && count > 0 -> Coral
                            count > 0 -> CoralDim
                            else -> CoralFaint
                        }
                    )
            )
        }
    }
}

// ================= About: the objective =================

@Composable
fun AboutScreen() {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Why this app", color = TextSoft, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Text("Every \"Mum\" is a moment of attention", color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Medium, lineHeight = 34.sp)
        Spacer(Modifier.height(16.dp))
        Text(
            "Mothers answer thousands of small calls every week. It rarely gets counted, because it never ends.\n\n" +
            "This app makes that invisible work visible. Tap each time you're called Mum. Your daily total is shared anonymously with mothers around the world, so together we can see what motherhood really asks of a person.",
            color = TextSoft, fontSize = 16.sp, lineHeight = 24.sp
        )
        Spacer(Modifier.height(24.dp))
        Column(Modifier.clip(RoundedCornerShape(16.dp)).background(Surface).padding(16.dp)) {
            Text("Your privacy", color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text(
                "Counts stay on your phone. Only an anonymous daily total and your country are shared. No audio, names, or exact location.",
                color = TextSoft, fontSize = 14.sp, lineHeight = 20.sp
            )
        }
    }
}

// ================= Share =================

fun shareCount(context: Context, count: Int) {
    val text = "I was called Mum $count times today. Every \"Mum\" is a moment of attention. Join the count."
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, "Share your count"))
}
